package keluarga_no_dip.research;

import java.util.List;
import keluarga_no_dip.models.Person;
import keluarga_no_dip.relationships.Relationships;

public class Research {
    public Research(Relationships relationships) {
        // Mencari dan menampilkan semua anak dari "John"
        List<Person> children = relationships.findAllChildrenOf("Eko");
        for (Person child : children) {
            System.out.println("Eko has a child named " + child.name);
        }
    }
}
