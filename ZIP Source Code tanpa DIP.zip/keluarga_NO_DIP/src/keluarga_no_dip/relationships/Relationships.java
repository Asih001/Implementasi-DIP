package keluarga_no_dip.relationships;

import java.util.ArrayList;
import java.util.List;
import keluarga_no_dip.models.Person;

public class Relationships {
    private List<Relationship> relations = new ArrayList<>();

    // Kelas Relationship internal
    private class Relationship {
        private Person parent;
        private Person child;

        public Relationship(Person parent, Person child) {
            this.parent = parent;
            this.child = child;
        }

        public Person getParent() {
            return parent;
        }

        public Person getChild() {
            return child;
        }
    }

    // Menambahkan hubungan orang tua dan anak
    public void addParentAndChild(Person parent, Person child) {
        relations.add(new Relationship(parent, child));
    }

    // Mencari semua anak dari orang tua dengan nama tertentu
    public List<Person> findAllChildrenOf(String name) {
        List<Person> children = new ArrayList<>();
        for (Relationship relation : relations) {
            if (relation.getParent().name.equals(name)) {
                children.add(relation.getChild());
            }
        }
        return children;
    }
}
