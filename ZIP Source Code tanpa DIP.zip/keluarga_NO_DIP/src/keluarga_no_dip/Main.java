/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package keluarga_no_dip;
import keluarga_no_dip.models.Person;
import keluarga_no_dip.relationships.Relationships;
import keluarga_no_dip.research.Research;

public class Main {
    public static void main(String[] args) {
        Person parent = new Person("Eko");
        Person child1 = new Person("Putri");
        Person child2 = new Person("Putra");

        Relationships relationships = new Relationships();
        relationships.addParentAndChild(parent, child1);
        relationships.addParentAndChild(parent, child2);

        new Research(relationships);  // Research langsung menggunakan Relationships
    }
}
