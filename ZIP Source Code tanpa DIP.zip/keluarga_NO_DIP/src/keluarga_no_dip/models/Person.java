package keluarga_no_dip.models;

public class Person {
    public String name;

    public Person(String name) {
        this.name = name;
    }
}
