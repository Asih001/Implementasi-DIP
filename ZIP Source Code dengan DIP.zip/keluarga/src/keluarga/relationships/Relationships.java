package keluarga.relationships;

import java.util.ArrayList;
import java.util.List;
import keluarga.models.Person;

public class Relationships implements RelationshipBrowser {

    // List untuk menyimpan hubungan keluarga
    private List<Relationship> relations = new ArrayList<>();

    // Menambahkan hubungan orang tua dan anak ke list
    public void addParentAndChild(Person parent, Person child) {
        relations.add(new Relationship(parent, child, "PARENT"));
    }

    // Implementasi metode dari interface RelationshipBrowser
    @Override
    public List<Person> findAllChildrenOf(String name) {
        List<Person> children = new ArrayList<>();
        for (Relationship relation : relations) {
            if (relation.getParent().name.equals(name) && relation.getRelationshipType().equals("PARENT")) {
                children.add(relation.getChild());
            }
        }
        return children;
    }
}
