package keluarga.relationships;

import keluarga.models.Person;
import java.util.List;

public interface RelationshipBrowser {
    List<Person> findAllChildrenOf(String name);
}
