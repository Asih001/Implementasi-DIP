package keluarga.relationships;

import keluarga.models.Person;

public class Relationship {
    private Person parent;
    private Person child;
    private String relationshipType;

    public Relationship(Person parent, Person child, String relationshipType) {
        this.parent = parent;
        this.child = child;
        this.relationshipType = relationshipType;
    }

    public Person getParent() {
        return parent;
    }

    public Person getChild() {
        return child;
    }

    public String getRelationshipType() {
        return relationshipType;
    }
}
