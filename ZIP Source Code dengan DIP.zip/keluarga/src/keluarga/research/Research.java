package keluarga.research;

import java.util.List;
import keluarga.models.Person;
import keluarga.relationships.RelationshipBrowser;

public class Research {
    public Research(RelationshipBrowser browser) {
        List<Person> children = browser.findAllChildrenOf("Eko");
        for (Person child : children) {
            System.out.println("Eko has a child named " + child.name);
        }
    }
}
